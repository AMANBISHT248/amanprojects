# TaskFlow — Task Management Application

Full-stack React + Node.js/Express + MongoDB task manager.

## Features
- Register/login with JWT authentication
- Protected user-specific task data
- Create, read, update, delete tasks
- Status, priority and due date
- Search and filter
- Responsive desktop/mobile UI

## Run
Requirements: Node.js 18+, MongoDB local or Atlas.

### Backend
```bash
cd server
npm install
copy .env.example .env
npm run dev
```
On macOS/Linux: `cp .env.example .env`

### Frontend
Open a second terminal:
```bash
cd client
npm install
npm run dev
```
Open the Vite URL, normally http://localhost:5173.

Edit `server/.env` if you use MongoDB Atlas.

Architecture: React → Axios → Express REST API → JWT middleware → MongoDB.
