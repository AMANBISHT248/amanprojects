import express from 'express'; import mongoose from 'mongoose'; import cors from 'cors'; import dotenv from 'dotenv';
import authRoutes from './routes/authRoutes.js'; import taskRoutes from './routes/taskRoutes.js';
dotenv.config(); const app=express(); app.use(cors({origin:process.env.CLIENT_URL||'http://localhost:5173'})); app.use(express.json());
app.get('/',(_,res)=>res.json({message:'TaskFlow API is running'})); app.use('/api/auth',authRoutes); app.use('/api/tasks',taskRoutes);
const PORT=process.env.PORT||5000; mongoose.connect(process.env.MONGO_URI).then(()=>app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`))).catch(e=>{console.error(e.message);process.exit(1)});
