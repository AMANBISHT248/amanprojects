# BlogSpace — Full-Stack Blog Platform

A full-stack blog platform with authentication, blog CRUD, REST APIs, MongoDB, and comments.

## Tech Stack
- Frontend: React + Vite + React Router + Axios
- Backend: Node.js + Express
- Database: MongoDB + Mongoose
- Authentication: JWT + bcryptjs

## Features
- User registration and login
- JWT authentication
- Create, edit, and delete your own posts
- View all posts and individual articles
- Authenticated comments
- Delete your own comments
- Ownership authorization for posts/comments
- RESTful API structure
- Responsive UI

## Project Structure
```
blog-platform/
├── client/              # React frontend
│   └── src/
│       ├── components/
│       ├── context/
│       ├── pages/
│       └── services/
├── server/              # Express backend
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   └── routes/
└── README.md
```

## Requirements
- Node.js 18+
- MongoDB local installation or MongoDB Atlas

## 1. Start MongoDB
For local MongoDB, make sure the MongoDB service is running.

## 2. Backend setup
```bash
cd server
npm install
```
Copy `.env.example` to `.env` and set `MONGO_URI` and a strong `JWT_SECRET`.

Run:
```bash
npm run dev
```
Backend: http://localhost:5000

## 3. Frontend setup
Open another terminal:
```bash
cd client
npm install
npm run dev
```
Frontend: http://localhost:5173

## REST API
### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`

### Posts
- `GET /api/posts`
- `GET /api/posts/:id`
- `POST /api/posts` — protected
- `PUT /api/posts/:id` — protected + owner only
- `DELETE /api/posts/:id` — protected + owner only

### Comments
- `POST /api/comments/:postId` — protected
- `DELETE /api/comments/:id` — protected + owner only

## Example register request
```json
{
  "name": "Aman",
  "email": "aman@example.com",
  "password": "password123"
}
```

## How to test
1. Register a user.
2. Login is automatic after registration.
3. Click **Write** and publish a post.
4. Open the post and add comments.
5. Register/login as another user to test interaction.
6. Verify that another user cannot edit/delete your post.

## Future upgrades
- Image upload with Cloudinary
- Rich text editor / Markdown
- Search and categories
- Likes and bookmarks
- Pagination
- Admin dashboard
- Email verification and password reset
