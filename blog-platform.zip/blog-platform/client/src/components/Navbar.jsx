import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
export default function Navbar() {
  const { user, logout } = useAuth();
  return <nav className="nav"><Link className="brand" to="/">BlogSpace</Link><div className="navlinks"><Link to="/">Home</Link>{user && <Link to="/create">Write</Link>}{user ? <><span className="welcome">Hi, {user.name}</span><button onClick={logout} className="linkbtn">Logout</button></> : <><Link to="/login">Login</Link><Link className="signup" to="/register">Register</Link></>}</div></nav>;
}
