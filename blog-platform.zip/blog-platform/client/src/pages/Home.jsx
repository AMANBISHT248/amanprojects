import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
export default function Home() {
  const [posts, setPosts] = useState([]); const { user } = useAuth();
  useEffect(() => { api.get('/posts').then(r => setPosts(r.data)).catch(console.error); }, []);
  return <main className="container"><section className="hero"><div><p className="eyebrow">FULL-STACK BLOG PLATFORM</p><h1>Share ideas.<br/><span>Start conversations.</span></h1><p>Create posts, connect with readers, and discuss ideas through comments.</p>{user ? <Link className="btn" to="/create">Write a post</Link> : <Link className="btn" to="/register">Get started</Link>}</div><div className="hero-card"><div>✍️</div><strong>Write & publish</strong><small>CRUD + REST APIs</small><div>💬</div><strong>Join discussions</strong><small>Authenticated comments</small></div></section><h2 className="section-title">Latest posts</h2><div className="grid">{posts.map(p => <article className="card" key={p._id}><p className="meta">{new Date(p.createdAt).toLocaleDateString()} · {p.author?.name}</p><h3>{p.title}</h3><p>{p.content.slice(0, 150)}{p.content.length > 150 ? '...' : ''}</p><Link to={`/posts/${p._id}`}>Read article →</Link></article>)}{posts.length === 0 && <p>No posts yet. Be the first to write one.</p>}</div></main>;
}
