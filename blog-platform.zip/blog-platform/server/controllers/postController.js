import Post from '../models/Post.js';
import Comment from '../models/Comment.js';

export async function getPosts(req, res) {
  try {
    const posts = await Post.find().populate('author', 'name').sort({ createdAt: -1 });
    res.json(posts);
  } catch (error) { res.status(500).json({ message: error.message }); }
}

export async function getPost(req, res) {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name email');
    if (!post) return res.status(404).json({ message: 'Post not found' });
    const comments = await Comment.find({ post: post._id }).populate('author', 'name').sort({ createdAt: -1 });
    res.json({ post, comments });
  } catch { res.status(400).json({ message: 'Invalid post id' }); }
}

export async function createPost(req, res) {
  try {
    const { title, content } = req.body;
    if (!title?.trim() || !content?.trim()) return res.status(400).json({ message: 'Title and content are required' });
    const post = await Post.create({ title, content, author: req.user.id });
    res.status(201).json(await post.populate('author', 'name'));
  } catch (error) { res.status(500).json({ message: error.message }); }
}

export async function updatePost(req, res) {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (String(post.author) !== req.user.id) return res.status(403).json({ message: 'You can edit only your own posts' });
    post.title = req.body.title ?? post.title;
    post.content = req.body.content ?? post.content;
    await post.save();
    res.json(await post.populate('author', 'name'));
  } catch { res.status(400).json({ message: 'Invalid post id' }); }
}

export async function deletePost(req, res) {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (String(post.author) !== req.user.id) return res.status(403).json({ message: 'You can delete only your own posts' });
    await Comment.deleteMany({ post: post._id });
    await post.deleteOne();
    res.json({ message: 'Post deleted' });
  } catch { res.status(400).json({ message: 'Invalid post id' }); }
}
