import Comment from '../models/Comment.js';
import Post from '../models/Post.js';

export async function addComment(req, res) {
  try {
    const { content } = req.body;
    if (!content?.trim()) return res.status(400).json({ message: 'Comment cannot be empty' });
    const post = await Post.findById(req.params.postId);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    const comment = await Comment.create({ content, post: post._id, author: req.user.id });
    res.status(201).json(await comment.populate('author', 'name'));
  } catch { res.status(400).json({ message: 'Invalid post id' }); }
}

export async function deleteComment(req, res) {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found' });
    if (String(comment.author) !== req.user.id) return res.status(403).json({ message: 'You can delete only your own comments' });
    await comment.deleteOne();
    res.json({ message: 'Comment deleted' });
  } catch { res.status(400).json({ message: 'Invalid comment id' }); }
}
