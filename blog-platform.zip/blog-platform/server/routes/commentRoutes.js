import { Router } from 'express';
import { addComment, deleteComment } from '../controllers/commentController.js';
import { protect } from '../middleware/auth.js';
const router = Router();
router.post('/:postId', protect, addComment);
router.delete('/:id', protect, deleteComment);
export default router;
