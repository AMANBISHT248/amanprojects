package com.example.ecommerce.controller;

import com.example.ecommerce.model.*;
import com.example.ecommerce.repository.UserRepository;
import com.example.ecommerce.security.JwtService;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController @RequestMapping("/api/auth")
public class AuthController {
 private final UserRepository repo; private final PasswordEncoder enc; private final JwtService jwt;
 public AuthController(UserRepository r,PasswordEncoder e,JwtService j){repo=r;enc=e;jwt=j;}
 @PostMapping("/register") public ResponseEntity<?> register(@RequestBody Map<String,String> b){
   if(repo.findByEmail(b.get("email")).isPresent()) return ResponseEntity.badRequest().body(Map.of("message","Email already exists"));
   User u=new User(); u.setName(b.get("name")); u.setEmail(b.get("email")); u.setPassword(enc.encode(b.get("password"))); u.setRole(Role.USER); repo.save(u);
   return ResponseEntity.ok(Map.of("token",jwt.generate(u.getEmail()),"role",u.getRole().name(),"name",u.getName()));
 }
 @PostMapping("/login") public ResponseEntity<?> login(@RequestBody Map<String,String> b){
   var u=repo.findByEmail(b.get("email")).orElse(null);
   if(u==null || !enc.matches(b.get("password"),u.getPassword())) return ResponseEntity.status(401).body(Map.of("message","Invalid credentials"));
   return ResponseEntity.ok(Map.of("token",jwt.generate(u.getEmail()),"role",u.getRole().name(),"name",u.getName()));
 }
}