package com.example.ecommerce.repository;
import com.example.ecommerce.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface CartItemRepository extends JpaRepository<CartItem,Long> {
 List<CartItem> findByUserId(Long userId);
 Optional<CartItem> findByUserIdAndProductId(Long userId, Long productId);
 void deleteByUserId(Long userId);
}