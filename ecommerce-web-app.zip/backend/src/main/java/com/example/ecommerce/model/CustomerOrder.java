package com.example.ecommerce.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.*;

@Entity
@Table(name="orders")
@Getter @Setter @NoArgsConstructor
public class CustomerOrder {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @ManyToOne(optional=false) private User user;
 private Double totalAmount;
 @Enumerated(EnumType.STRING) private OrderStatus status = OrderStatus.PLACED;
 private LocalDateTime createdAt = LocalDateTime.now();
 @OneToMany(cascade=CascadeType.ALL)
 private List<OrderItem> items = new ArrayList<>();
}