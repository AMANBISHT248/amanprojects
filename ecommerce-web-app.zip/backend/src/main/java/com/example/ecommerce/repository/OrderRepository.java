package com.example.ecommerce.repository;
import com.example.ecommerce.model.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface OrderRepository extends JpaRepository<CustomerOrder,Long> {
 List<CustomerOrder> findByUserIdOrderByCreatedAtDesc(Long userId);
}