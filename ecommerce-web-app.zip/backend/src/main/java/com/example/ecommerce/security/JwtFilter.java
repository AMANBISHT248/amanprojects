package com.example.ecommerce.security;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {
 private final JwtService jwt; private final com.example.ecommerce.repository.UserRepository users;
 public JwtFilter(JwtService jwt, com.example.ecommerce.repository.UserRepository users){this.jwt=jwt;this.users=users;}
 protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
   String h=req.getHeader("Authorization");
   if(h!=null && h.startsWith("Bearer ")){
     try{
       String email=jwt.email(h.substring(7));
       var u=users.findByEmail(email).orElse(null);
       if(u!=null) SecurityContextHolder.getContext().setAuthentication(
         new UsernamePasswordAuthenticationToken(u.getEmail(),null,List.of(()->"ROLE_"+u.getRole().name())));
     }catch(Exception ignored){}
   }
   chain.doFilter(req,res);
 }
}