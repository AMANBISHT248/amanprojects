package com.example.ecommerce.controller;

import com.example.ecommerce.model.*;
import com.example.ecommerce.repository.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api")
public class ShopController {
 private final UserRepository users; private final ProductRepository products; private final CartItemRepository cart; private final OrderRepository orders;
 public ShopController(UserRepository u,ProductRepository p,CartItemRepository c,OrderRepository o){users=u;products=p;cart=c;orders=o;}
 private User user(Authentication a){return users.findByEmail(a.getName()).orElseThrow();}
 @GetMapping("/cart") public List<CartItem> getCart(Authentication a){return cart.findByUserId(user(a).getId());}
 @PostMapping("/cart") public CartItem add(Authentication a,@RequestBody Map<String,Integer> b){
   User u=user(a); Long pid=Long.valueOf(b.get("productId")); int qty=b.getOrDefault("quantity",1);
   var item=cart.findByUserIdAndProductId(u.getId(),pid).orElseGet(()->{CartItem x=new CartItem();x.setUser(u);x.setProduct(products.findById(pid).orElseThrow());x.setQuantity(0);return x;});
   item.setQuantity(item.getQuantity()+qty); return cart.save(item);
 }
 @PutMapping("/cart/{id}") public CartItem update(@PathVariable Long id,@RequestBody Map<String,Integer> b,Authentication a){
   var x=cart.findById(id).orElseThrow(); x.setQuantity(b.get("quantity")); return cart.save(x);
 }
 @DeleteMapping("/cart/{id}") public void remove(@PathVariable Long id){cart.deleteById(id);}
 @PostMapping("/orders") public CustomerOrder checkout(Authentication a){
   User u=user(a); var items=cart.findByUserId(u.getId()); if(items.isEmpty()) throw new IllegalStateException("Cart is empty");
   CustomerOrder o=new CustomerOrder(); o.setUser(u); double total=0;
   for(var c:items){OrderItem oi=new OrderItem();oi.setProduct(c.getProduct());oi.setQuantity(c.getQuantity());oi.setPrice(c.getProduct().getPrice());o.getItems().add(oi);total+=c.getQuantity()*c.getProduct().getPrice();}
   o.setTotalAmount(total); var saved=orders.save(o); cart.deleteByUserId(u.getId()); return saved;
 }
 @GetMapping("/orders") public List<CustomerOrder> myOrders(Authentication a){return orders.findByUserIdOrderByCreatedAtDesc(user(a).getId());}
}