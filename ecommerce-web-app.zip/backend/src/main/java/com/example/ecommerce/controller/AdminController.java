package com.example.ecommerce.controller;

import com.example.ecommerce.model.*;
import com.example.ecommerce.repository.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/admin")
public class AdminController {
 private final ProductRepository products; private final OrderRepository orders;
 public AdminController(ProductRepository p,OrderRepository o){products=p;orders=o;}
 @PostMapping("/products") public Product add(@RequestBody Product p){return products.save(p);}
 @PutMapping("/products/{id}") public Product update(@PathVariable Long id,@RequestBody Product p){p.setId(id);return products.save(p);}
 @DeleteMapping("/products/{id}") public void delete(@PathVariable Long id){products.deleteById(id);}
 @GetMapping("/orders") public List<CustomerOrder> orders(){return orders.findAll();}
 @PutMapping("/orders/{id}/status") public CustomerOrder status(@PathVariable Long id,@RequestParam OrderStatus status){
   var o=orders.findById(id).orElseThrow(); o.setStatus(status); return orders.save(o);
 }
}