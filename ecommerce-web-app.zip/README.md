# E-Commerce Web Application

Full-stack starter project using React + Vite, Spring Boot, JWT, and MySQL.

## Features
- Product catalog, search, category filter
- Register/login with JWT
- USER / ADMIN role-based access
- Cart and checkout
- Order history
- Admin product CRUD
- Admin order management
- REST APIs
- MySQL persistence

## Requirements
- Java 17+
- Maven 3.9+
- Node.js 20+
- MySQL 8+

## Database
Create a database:
```sql
CREATE DATABASE ecommerce_db;
```

Backend defaults are in `backend/src/main/resources/application.properties`.

Run backend:
```bash
cd backend
mvn spring-boot:run
```

Run frontend:
```bash
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:8080

## Demo admin
After registering a user, change its role to ADMIN in MySQL:
```sql
UPDATE users SET role='ADMIN' WHERE email='admin@example.com';
```

Never hard-code production passwords or JWT secrets.
