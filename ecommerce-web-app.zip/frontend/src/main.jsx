import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {BrowserRouter,useNavigate} from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './style.css';

const API='http://localhost:8080/api';
const client=axios.create({baseURL:API});
client.interceptors.request.use(c=>{const t=localStorage.getItem('token');if(t)c.headers.Authorization=`Bearer ${t}`;return c;});

function App(){
 const [products,setProducts]=useState([]),[cart,setCart]=useState([]),[user,setUser]=useState(JSON.parse(localStorage.getItem('user')||'null'));
 const [view,setView]=useState('shop'),[search,setSearch]=useState('');
 const load=async()=>{const p=await client.get('/products');setProducts(p.data);if(user){const c=await client.get('/cart');setCart(c.data)}};
 useEffect(()=>{load()},[user]);
 const login=(data)=>{localStorage.setItem('token',data.token);localStorage.setItem('user',JSON.stringify(data));setUser(data);setView('shop')};
 const logout=()=>{localStorage.clear();setUser(null);setCart([])};
 const add=async(id)=>{if(!user){setView('login');return}await client.post('/cart',{productId:id,quantity:1});const c=await client.get('/cart');setCart(c.data)};
 const checkout=async()=>{await client.post('/orders');setCart([]);alert('Order placed successfully!');setView('orders')};
 const shown=products.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())||p.category?.toLowerCase().includes(search.toLowerCase()));
 return <div>
  <nav className="navbar navbar-expand-lg bg-dark navbar-dark px-4"><span className="navbar-brand fw-bold">ShopHub</span>
   <div className="ms-auto d-flex gap-2 align-items-center"><button className="btn btn-sm btn-outline-light" onClick={()=>setView('shop')}>Shop</button>
   {user&&<><button className="btn btn-sm btn-outline-light" onClick={()=>setView('orders')}>Orders</button><button className="btn btn-sm btn-warning" onClick={()=>setView('cart')}>Cart ({cart.reduce((s,x)=>s+x.quantity,0)})</button>{user.role==='ADMIN'&&<button className="btn btn-sm btn-info" onClick={()=>setView('admin')}>Admin</button>}<button className="btn btn-sm btn-danger" onClick={logout}>Logout</button></>}
   {!user&&<button className="btn btn-sm btn-success" onClick={()=>setView('login')}>Login</button>}</div></nav>
  <main className="container py-4">
   {view==='shop'&&<><div className="hero p-4 rounded mb-4"><h1>Modern Shopping, Simple Checkout</h1><p>Browse products and add your favourites to the cart.</p><input className="form-control" placeholder="Search products..." value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="row g-4">{shown.map(p=><div className="col-md-4" key={p.id}><div className="card h-100 shadow-sm"><img src={p.imageUrl||'https://placehold.co/600x400?text=Product'} className="card-img-top product-img"/><div className="card-body"><h5>{p.name}</h5><p className="text-secondary">{p.description}</p><div className="d-flex justify-content-between align-items-center"><b>₹{p.price}</b><button className="btn btn-primary" onClick={()=>add(p.id)}>Add to Cart</button></div></div></div></div>)}</div></>}
   {view==='login'&&<Auth onLogin={login}/>}
   {view==='cart'&&<Cart cart={cart} setCart={setCart} checkout={checkout}/>}
   {view==='orders'&&<Orders/>}
   {view==='admin'&&user?.role==='ADMIN'&&<Admin reload={load}/>}
  </main>
 </div>
}

function Auth({onLogin}){const [mode,setMode]=useState('login'),[form,setForm]=useState({name:'',email:'',password:''});
 const submit=async e=>{e.preventDefault();try{const r=await client.post('/auth/'+mode,form);onLogin(r.data)}catch(err){alert(err.response?.data?.message||'Request failed')}};
 return <div className="auth card shadow p-4"><h2>{mode==='login'?'Login':'Create account'}</h2><form onSubmit={submit}>{mode==='register'&&<input className="form-control mb-3" placeholder="Name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>}<input className="form-control mb-3" placeholder="Email" type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input className="form-control mb-3" placeholder="Password" type="password" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/><button className="btn btn-primary w-100">{mode==='login'?'Login':'Register'}</button></form><button className="btn btn-link mt-2" onClick={()=>setMode(mode==='login'?'register':'login')}>{mode==='login'?'Create account':'Already have an account?'}</button></div>}

function Cart({cart,setCart,checkout}){const update=async(id,q)=>{if(q<1)return;await client.put('/cart/'+id,{quantity:q});setCart((await client.get('/cart')).data)};const remove=async id=>{await client.delete('/cart/'+id);setCart((await client.get('/cart')).data)};const total=cart.reduce((s,x)=>s+x.product.price*x.quantity,0);return <div><h2>Your Cart</h2>{cart.length===0?<p>Your cart is empty.</p>:<><div className="list-group mb-3">{cart.map(x=><div className="list-group-item d-flex justify-content-between align-items-center" key={x.id}><div><b>{x.product.name}</b><div>₹{x.product.price} × {x.quantity}</div></div><div><button className="btn btn-sm btn-outline-secondary" onClick={()=>update(x.id,x.quantity-1)}>-</button><button className="btn btn-sm btn-outline-secondary mx-1">{x.quantity}</button><button className="btn btn-sm btn-outline-secondary" onClick={()=>update(x.id,x.quantity+1)}>+</button><button className="btn btn-sm btn-outline-danger ms-2" onClick={()=>remove(x.id)}>Remove</button></div></div>)}</div><h4>Total: ₹{total.toFixed(2)}</h4><button className="btn btn-success" onClick={checkout}>Checkout</button></>}</div>}

function Orders(){const [orders,setOrders]=useState([]);useEffect(()=>{client.get('/orders').then(r=>setOrders(r.data))},[]);return <div><h2>My Orders</h2>{orders.map(o=><div className="card mb-3 p-3" key={o.id}><b>Order #{o.id}</b><span>Status: {o.status}</span><span>Total: ₹{o.totalAmount}</span></div>)}</div>}

function Admin({reload}){const [products,setProducts]=useState([]),[form,setForm]=useState({name:'',description:'',price:'',category:'',stock:10,imageUrl:''});const load=()=>client.get('/products').then(r=>setProducts(r.data));useEffect(load,[]);const add=async e=>{e.preventDefault();await client.post('/admin/products',{...form,price:Number(form.price),stock:Number(form.stock)});setForm({name:'',description:'',price:'',category:'',stock:10,imageUrl:''});load();reload()};const del=async id=>{await client.delete('/admin/products/'+id);load();reload()};return <div><h2>Admin Dashboard</h2><form className="card p-3 mb-4" onSubmit={add}><h5>Add Product</h5><div className="row g-2">{Object.keys(form).map(k=><div className="col-md-4" key={k}><input className="form-control" placeholder={k} required={k==='name'||k==='price'} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})}/></div>)}</div><button className="btn btn-dark mt-3">Add Product</button></form><div className="list-group">{products.map(p=><div className="list-group-item d-flex justify-content-between" key={p.id}>{p.name}<button className="btn btn-sm btn-danger" onClick={()=>del(p.id)}>Delete</button></div>)}</div></div>}

createRoot(document.getElementById('root')).render(<BrowserRouter><App/></BrowserRouter>);
