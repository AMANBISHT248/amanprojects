# Aman Bisht — Full Stack Portfolio

A responsive portfolio built with:

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express.js
- Database: MongoDB + Mongoose
- API: REST API

## 1. Install MongoDB

Install MongoDB locally, or create a MongoDB Atlas database.

For local MongoDB, the default database URL is:

`mongodb://127.0.0.1:27017/aman_portfolio`

## 2. Start the backend

Open a terminal:

```bash
cd backend
npm install
```

Copy `.env.example` to `.env`.

Then run:

```bash
node seed.js
npm start
```

The API will run at:

`http://localhost:5000`

Test:

`http://localhost:5000/api/health`

## 3. Open the frontend

Open:

`frontend/index.html`

in your browser.

The Projects section will fetch project details from MongoDB through the Express API.

## 4. Add a project through API

Use Postman:

POST `http://localhost:5000/api/projects`

JSON:

```json
{
  "title": "My New Project",
  "category": "FULL STACK",
  "description": "My project description.",
  "technologies": ["React.js", "Node.js", "MongoDB"],
  "link": "https://github.com/yourusername/project"
}
```

## 5. Important customization

Replace these placeholders in `frontend/index.html`:

- `Add your GitHub URL`
- `Add your LinkedIn URL`

Your email and phone have already been added from the resume.

## Project data

The initial projects are based on the projects listed in the provided resume:
- Realtime Group Chat App using React.js & Socket.IO
- Movie Search Website using React and API
- Roshambo / Stone, Paper, Scissors

The resume also lists your MCA at ABES Engineering College with CGPA 9.0 and your BCA with 71.72%.
