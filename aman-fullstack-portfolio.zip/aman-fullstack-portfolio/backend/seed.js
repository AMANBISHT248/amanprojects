require("dotenv").config();
const mongoose = require("mongoose");
const Project = require("./models/Project");

const projects = [
  {
    title: "Realtime Group Chat App",
    category: "FULL STACK",
    description: "A real-time group chat application with React.js and Socket.IO for bidirectional communication between multiple users.",
    technologies: ["React.js", "Node.js", "Express.js", "Socket.IO"],
    link: ""
  },
  {
    title: "Movie Search Website",
    category: "FRONTEND",
    description: "A movie search website using React and a movie database API to search for and view movie details.",
    technologies: ["React.js", "JavaScript", "REST API", "CSS"],
    link: ""
  },
  {
    title: "Roshambo",
    category: "JAVASCRIPT",
    description: "A Stone, Paper, Scissors game where the player picks an option and the computer randomly selects one.",
    technologies: ["HTML", "CSS", "JavaScript"],
    link: ""
  }
];

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI);
  await Project.deleteMany({});
  await Project.insertMany(projects);
  console.log("Projects inserted successfully.");
  await mongoose.disconnect();
}

seed().catch(error => {
  console.error(error);
  process.exit(1);
});
