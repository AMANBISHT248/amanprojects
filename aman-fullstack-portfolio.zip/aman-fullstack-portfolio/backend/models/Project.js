const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  category: String,
  description: { type: String, required: true },
  technologies: [String],
  link: String
}, { timestamps: true });

module.exports = mongoose.model("Project", projectSchema);
