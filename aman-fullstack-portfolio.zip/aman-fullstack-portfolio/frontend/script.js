const API_URL = "http://localhost:5000/api";

document.getElementById("year").textContent = new Date().getFullYear();

async function loadProjects() {
  const list = document.getElementById("project-list");
  try {
    const response = await fetch(`${API_URL}/projects`);
    if (!response.ok) throw new Error("Could not load projects");
    const projects = await response.json();

    list.innerHTML = projects.map(project => `
      <article class="project-card">
        <div class="section-label">${project.category || "PROJECT"}</div>
        <h3>${escapeHtml(project.title)}</h3>
        <p>${escapeHtml(project.description)}</p>
        <div class="tags">
          ${(project.technologies || []).map(t => `<span class="tag">${escapeHtml(t)}</span>`).join("")}
        </div>
        ${project.link ? `<a class="project-link" href="${project.link}" target="_blank" rel="noopener">View Project →</a>` : ""}
      </article>
    `).join("");
  } catch (error) {
    list.innerHTML = `<p>Projects could not be loaded. Start the backend server first.</p>`;
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

document.getElementById("contact-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target;
  const status = document.getElementById("form-status");
  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const response = await fetch(`${API_URL}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Message failed");
    status.textContent = "Message sent successfully.";
    form.reset();
  } catch (error) {
    status.textContent = error.message;
  }
});

loadProjects();
